using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarController : MonoBehaviour
{
    public float maxSpeed = 50f;
    public float acceleration = 20f;
    public float steering = 5f;
    public float jumpForce = 10f;
    public float raycastDistance = 1f;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        Vector3 movement = transform.forward * vertical * acceleration;
        transform.Rotate(0, horizontal * steering, 0);
        rb.AddForce(movement, ForceMode.Acceleration);

        RaycastHit hit;
        if (Physics.Raycast(transform.position, -transform.up, out hit, raycastDistance))
        {
            float angle = Vector3.Angle(transform.up, hit.normal);

            if (angle > 30f)
            {
                Vector3 axis = Vector3.Cross(transform.up, hit.normal);
                rb.AddTorque(axis * angle * angle, ForceMode.VelocityChange);
            }
            else
            {
                rb.velocity = Vector3.zero;
                rb.angularVelocity = Vector3.zero;
            }
        }
    }
}
