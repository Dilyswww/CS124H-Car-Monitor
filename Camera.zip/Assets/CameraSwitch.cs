using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraSwitch : MonoBehaviour
{
    // Change Camera Location
    [SerializeField] public GameObject maincamera;
    [SerializeField] public GameObject closeupcamera;
    [SerializeField] public GameObject backcamera;
    [SerializeField] public GameObject car;

    // Get Input
    // private bool main;
    // private bool close;
    // private bool back;
    // private bool mybool;

    private void FixedUpdate() 
    {
        // GetInput();
        // ChangeCameraLocation();

        if (Input.GetButtonDown("MainCamera"))
        {
            maincamera.SetActive(true);
            closeupcamera.SetActive(false);
            backcamera.SetActive(false);
        }

        if (Input.GetButtonDown("CloseupCamera"))
        {
            closeupcamera.SetActive(true);
            maincamera.SetActive(false);
            backcamera.SetActive(false);
        }

        if (Input.GetButtonDown("BackCamera"))
        {
            backcamera.SetActive(true);
            maincamera.SetActive(false);
            closeupcamera.SetActive(false);
        }
    }

    // private void GetInput()
    // {
    //     // main = Input.GetButtonDown("MainCamera");
    //     // close = Input.GetButtonDown("CloseupCamera");
    //     // back = Input.GetButtonDown("BackCamera");
    //     main = Input.GetKeyDown(KeyCode.Keypad1);
    //     close = Input.GetKeyDown(KeyCode.Keypad2);
    //     back = Input.GetKeyDown(KeyCode.Keypad3);
    // }

    // private void ChangeCameraLocation()
    // {
    //     if (Input.GetKeyDown(KeyCode.Keypad1))
    //     {
    //         maincamera.SetActive(true);
    //         closeupcamera.SetActive(false);
    //         backcamera.SetActive(false);
    //     }

    //     if (Input.GetKeyDown(KeyCode.Keypad2))
    //     {
    //         closeupcamera.SetActive(true);
    //         maincamera.SetActive(false);
    //         backcamera.SetActive(false);
    //     }

    //     if (Input.GetKeyDown(KeyCode.Keypad3))
    //     {
    //         backcamera.SetActive(true);
    //         maincamera.SetActive(false);
    //         closeupcamera.SetActive(false);
    //     }
    // }
}
