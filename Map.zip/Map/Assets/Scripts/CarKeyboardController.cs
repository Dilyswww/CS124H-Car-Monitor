using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarKeyboardController : MonoBehaviour
{
    public float maxSpeed = 50f;
    public float acceleration = 20f;
    public float braking = 40f;

    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        float speed = Input.GetAxis("Vertical") * acceleration;

        if (speed < 0 && rb.velocity.z > 0)
        {
            rb.AddForce(new Vector3(0, 0, -braking), ForceMode.Acceleration);
        }
        else if (speed > 0 && rb.velocity.z < 0)
        {
            rb.AddForce(new Vector3(0, 0, braking), ForceMode.Acceleration);
        }

        rb.AddRelativeForce(new Vector3(0, 0, speed), ForceMode.Acceleration);

        if (rb.velocity.magnitude > maxSpeed)
        {
            rb.velocity = rb.velocity.normalized * maxSpeed;
        }
    }
}
